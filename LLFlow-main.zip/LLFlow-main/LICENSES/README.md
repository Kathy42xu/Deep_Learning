# License and Acknowledgement
A big thanks to following contributes that open sourced their code and therefore helped us a lot in developing LLFlow!

## SRFlow
The conditional normalizing flow partly follows https://github.com/andreas128/SRFlow

## BasicSR
The training framework was adapted from https://github.com/xinntao/BasicSR

## GLOW
The Normalizing Flow modules were adapted from https://github.com/chaiyujin/glow-pytorch
