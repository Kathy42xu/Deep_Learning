

Run matlab file [main_denoising_gray.m](https://github.com/cszn/KAIR/blob/master/matlab/main_denoising_gray.m) for local zoom.

```matlab
upperleft_pixel =  [172, 218];
box             =  [35, 35];
zoomfactor      =  3;
zoom_position   =  'ur';  % 'ur' = 'upper-right'
nline           =  2;
```

<img src="https://github.com/cszn/KAIR/blob/master/matlab/denoising_gray/05_drunet_2731.png" width="256px"/> <img src="https://github.com/cszn/KAIR/blob/master/matlab/denoising_gray_results/05_drunet_2731.png" width="256px"/>




