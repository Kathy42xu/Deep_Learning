put training data into trainsets
